export const BASE_URL = "http://localhost:3001/api/"; // server url
